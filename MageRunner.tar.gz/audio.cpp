#include "audio.hpp"

void PlaySpellSound(SDL_AudioDeviceID& deviceId, SDL_AudioSpec* wavSpec, Uint32 wavLength, Uint8* wavBuffer)
{
  deviceId = SDL_OpenAudioDevice(NULL, 0, wavSpec, NULL, 0);
  SDL_QueueAudio(deviceId, wavBuffer, wavLength);
  SDL_PauseAudioDevice(deviceId, 0);
}

void UpdateAudio(SDL_AudioDeviceID& deviceId, SDL_AudioSpec& wavSpec, Uint32 wavLength, Uint8* wavBuffer, bool& castNow)
{
  if(castNow)
  {
    PlaySpellSound(deviceId, &wavSpec, wavLength, wavBuffer);
    castNow = false;
  }
}

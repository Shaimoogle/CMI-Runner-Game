#include "environnement.hpp"

void moveEnemy(float &enemyPosition, int gameSpeed)
{
  enemyPosition = enemyPosition - gameSpeed;
  if(enemyPosition < 0)
  {
    enemyPosition = 0;
  }
}

void checkDefeat(bool &gameover, float enemyPosition)
{
  gameover = (enemyPosition == 0);
  if(gameover)
  {
    cout << "GAME OVER : YOU LOOSE" << endl;
  }
}

void checkEnemyDeath(int* weaknessesArray, int enemyId, int& spellId, bool &enemyAlive)
{
  if(weaknessesArray[enemyId] == spellId)
  {
    enemyAlive = false;
  }
}

void generateEnemy(float &enemyPosition, int &enemyId, bool &enemyAlive, bool& canCast, int& score)
{
  enemyId = rand () % 3;
  enemyPosition = 100.0F;
  enemyAlive = true;
  canCast = true;
  ++score;
}

void castSpell(int input, int& spellId, bool& canCast)
{
  spellId = -1;
  if(canCast && input != -1 && input != 0)
  {
    spellId = input;
    canCast = false;
  }
}

void UpdateEnvironment(int input, float& enemyPosition, bool& gameover, int& enemyId, int& spellId, bool& canCast, int* enemyWeaknesses, bool& enemyAlive, float& gameSpeed, int& score)
{
  moveEnemy(enemyPosition, gameSpeed);
  castSpell(input, spellId, canCast);
  checkEnemyDeath(enemyWeaknesses, enemyId, spellId, enemyAlive);
  if(!enemyAlive)
  {
    generateEnemy(enemyPosition, enemyId, enemyAlive, canCast, score);
  }
  else
  {
    checkDefeat(gameover, enemyPosition);
  }
}

void PrintEnvironment(int input, float enemyPosition, bool gameover, int enemyId, int spellId, bool canCast, bool enemyAlive, float gameSpeed)
{
  cout << "Input : " << input << endl;
  cout << "gameover : " << gameover << endl;

  cout << "enemyPosition : " << enemyPosition << endl;
  cout << "enemyId : " << enemyId << endl;
  cout << "spellId : " << spellId << endl;
  cout << "canCast : " << canCast << endl;

  cout << "enemyAlive : " << enemyAlive << endl;
  cout << "gameSpeed : "  << gameSpeed << endl;
  cout << "----------------------" << endl;
}

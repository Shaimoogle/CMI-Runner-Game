#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

void CreateWindow(SDL_Window*& window, SDL_Renderer*& renderer);
void DestroyWindow(SDL_Window* window, SDL_Renderer* renderer);

void DisplayMenu(SDL_Renderer* renderer);
void DisplayHero(SDL_Renderer* renderer, int& heroSpritePositionY, bool& heroSpriteGoingUp);
void DisplayEnemy(SDL_Renderer* renderer, int& enemySpritePositionX, float enemyPosition, int enemyId);
void DisplayWall(SDL_Renderer* renderer, int& wall1SpritePositionX, int& wall2SpritePositionX);
void DisplayScore(SDL_Renderer* renderer, int score, TTF_Font* scoreFont, SDL_Color white);
void DisplaySpell(SDL_Renderer* renderer, int enemySpritePositionX, int spellId);
void DisplayBook(SDL_Renderer* renderer, bool canCast);
void DisplayGameover(SDL_Renderer* renderer);

void UpdateGraphics(SDL_Window* window, SDL_Renderer* renderer, int& heroSpritePositionY, bool& heroSpriteGoingUp, int& enemySpritePositionX, float enemyPosition, int enemyId, int& wall1SpritePositionX, int& wall2SpritePositionX, int score, TTF_Font* scoreFont, SDL_Color white, int spellId, bool canCast);

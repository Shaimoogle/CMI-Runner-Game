#include <stdlib.h>
#include <stdio.h>
#include <SDL2/SDL.h>
#include <iostream>

void UpdateInput(int &input);
void MenuInput(bool &quit);
void ContinueInput(bool &replay, int& gameoverInput);

#include "graphics.hpp"

void CreateWindow(SDL_Window*& window, SDL_Renderer*& renderer)
{
  //Generating window
  window = SDL_CreateWindow("MageRunner", 0, 0, 16*80, 9*80, 0);
  renderer = SDL_CreateRenderer(window, -1, 0);

  if (window == NULL)
  {
        printf("Could not create window: %s\n", SDL_GetError());
  }
}

void DestroyWindow(SDL_Window* window, SDL_Renderer* renderer)
{
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
}

void DisplayMenu(SDL_Renderer* renderer)
{
  SDL_Surface* menuSurface;
  SDL_Texture* menuTexture;

  menuSurface = IMG_Load("menu.png");
  menuTexture = SDL_CreateTextureFromSurface(renderer, menuSurface);
  SDL_FreeSurface(menuSurface);

  SDL_Rect menuTransform;
  menuTransform.x = 0;
  menuTransform.y = 0;
  menuTransform.w = 1280;
  menuTransform.h = 720;

  SDL_RenderCopy(renderer, menuTexture, NULL, &menuTransform);
  SDL_DestroyTexture(menuTexture);
  SDL_RenderPresent(renderer);

}

void DisplayHero(SDL_Renderer* renderer, int& heroSpritePositionY, bool& heroSpriteGoingUp)
{
  SDL_Surface* heroSurface;
  SDL_Texture* heroTexture;

  heroSurface = IMG_Load("hero.png");
  heroTexture = SDL_CreateTextureFromSurface(renderer, heroSurface);
  SDL_FreeSurface(heroSurface);

  if(heroSpriteGoingUp)
  {
    ++heroSpritePositionY;
  }
  else
  {
    --heroSpritePositionY;
  }

  if(heroSpritePositionY == 20 || heroSpritePositionY == 0)
  {
    heroSpriteGoingUp = !heroSpriteGoingUp;
  }

  SDL_Rect heroTransform;
  heroTransform.x = -20;
  heroTransform.y = 460 + heroSpritePositionY;
  heroTransform.w = 320;
  heroTransform.h = 240;

  SDL_RenderCopy(renderer, heroTexture, NULL, &heroTransform);
  SDL_DestroyTexture(heroTexture);
}

void DisplayEnemy(SDL_Renderer* renderer, int& enemySpritePositionX, float enemyPosition, int enemyId)
{
  SDL_Surface* enemySurface;
  SDL_Texture* enemyTexture;

  if(enemyId == 0)
  {
    enemySurface = IMG_Load("reddemon.png");
  }
  else if(enemyId == 1)
  {
    enemySurface = IMG_Load("bluedemon.png");
  }
  else
  {
    enemySurface = IMG_Load("greendemon.png");
  }

  enemyTexture = SDL_CreateTextureFromSurface(renderer, enemySurface);
  SDL_FreeSurface(enemySurface);

  enemySpritePositionX = enemyPosition * 9.8F;

  SDL_Rect enemyTransform;
  enemyTransform.x = 300 + enemySpritePositionX;
  enemyTransform.y = 480;
  enemyTransform.w = 320;
  enemyTransform.h = 240;

  SDL_RenderCopy(renderer, enemyTexture, NULL, &enemyTransform);
  SDL_DestroyTexture(enemyTexture);
}

void DisplayWall(SDL_Renderer* renderer, int& wall1SpritePositionX, int& wall2SpritePositionX){

  SDL_Surface* wall1Surface;
  SDL_Texture* wall1Texture;
  SDL_Surface* wall2Surface;
  SDL_Texture* wall2Texture;

  wall1Surface = IMG_Load("mur1.png");
  wall2Surface = IMG_Load("mur1.png");

  wall1Texture = SDL_CreateTextureFromSurface(renderer, wall1Surface);
  SDL_FreeSurface(wall1Surface);
  wall2Texture = SDL_CreateTextureFromSurface(renderer, wall2Surface);
  SDL_FreeSurface(wall2Surface);

  wall1SpritePositionX = wall1SpritePositionX - 50;
  wall2SpritePositionX = wall2SpritePositionX - 50;

  if(wall1SpritePositionX <= -1280){
    wall1SpritePositionX = 0;
    wall2SpritePositionX = 1280;
  }

  SDL_Rect wall1Transform;
  wall1Transform.x = wall1SpritePositionX;
  wall1Transform.y = 0;
  wall1Transform.w = 1280;
  wall1Transform.h = 720;

  SDL_Rect wall2Transform;
  wall2Transform.x = wall2SpritePositionX;
  wall2Transform.y = 0;
  wall2Transform.w = 1280;
  wall2Transform.h = 720;

  SDL_RenderCopy(renderer, wall1Texture, NULL, &wall1Transform);
  SDL_DestroyTexture(wall1Texture);
  SDL_RenderCopy(renderer, wall2Texture, NULL, &wall2Transform);
  SDL_DestroyTexture(wall2Texture);

}

void DisplayScore(SDL_Renderer* renderer, int score, TTF_Font* scoreFont, SDL_Color white)
{
  SDL_Surface* scoreSurface;
  SDL_Texture* scoreTexture;

  const char* scoreText;
  scoreText = to_string(score).c_str();

  scoreSurface = TTF_RenderText_Blended(scoreFont, scoreText, white);
  scoreTexture = SDL_CreateTextureFromSurface(renderer, scoreSurface);

  SDL_Rect scoreTransform;
  scoreTransform.x = 80;
  scoreTransform.y = 80;
  scoreTransform.w = 100;
  scoreTransform.h = 100;

  SDL_RenderCopy(renderer, scoreTexture, NULL, &scoreTransform);
  SDL_FreeSurface(scoreSurface);
  SDL_DestroyTexture(scoreTexture);
}

void DisplaySpell(SDL_Renderer* renderer, int enemySpritePositionX, int spellId)
{
  if(spellId != -1)
  {
    SDL_Surface* spellSurface;
    SDL_Texture* spellTexture;
    switch(spellId)
    {
      case 1 :
      spellSurface = IMG_Load("blueattack.png");
      break;
      case 2 :
      spellSurface = IMG_Load("greenattack.png");
      break;
      case 3:
      spellSurface = IMG_Load("redattack.png");
      break;
    }

    spellTexture = SDL_CreateTextureFromSurface(renderer, spellSurface);
    SDL_FreeSurface(spellSurface);

    SDL_Rect spellTransform;
    spellTransform.x = 300 + enemySpritePositionX;
    spellTransform.y = 480;
    spellTransform.w = 320;
    spellTransform.h = 240;

    SDL_RenderCopy(renderer, spellTexture, NULL, &spellTransform);
    SDL_DestroyTexture(spellTexture);

  }
}

void DisplayBook(SDL_Renderer* renderer, bool canCast)
{
  SDL_Surface* bookSurface;
  SDL_Texture* bookTexture;

  bookSurface = IMG_Load("book.png");
  bookTexture = SDL_CreateTextureFromSurface(renderer, bookSurface);
  SDL_FreeSurface(bookSurface);

  if(!canCast)
  {
    SDL_SetTextureAlphaMod(bookTexture, 50);
  }

  SDL_Rect bookTransform;
  bookTransform.x = 1280 - 80 - 100;
  bookTransform.y = 80;
  bookTransform.w = 100;
  bookTransform.h = 100;

  SDL_RenderCopy(renderer, bookTexture, NULL, &bookTransform);
  SDL_DestroyTexture(bookTexture);

}

void DisplayGameover(SDL_Renderer* renderer)
{
  SDL_Surface* gameoverSurface;
  SDL_Texture* gameoverTexture;

  gameoverSurface = IMG_Load("gameover.png");
  gameoverTexture = SDL_CreateTextureFromSurface(renderer, gameoverSurface);
  SDL_FreeSurface(gameoverSurface);

  SDL_Rect gameoverTransform;
  gameoverTransform.x = 0;
  gameoverTransform.y = 0;
  gameoverTransform.w = 1280;
  gameoverTransform.h = 720;

  SDL_RenderCopy(renderer, gameoverTexture, NULL, &gameoverTransform);
  SDL_DestroyTexture(gameoverTexture);
  SDL_RenderPresent(renderer);
}

void UpdateGraphics(SDL_Window* window, SDL_Renderer* renderer, int& sprHeroPosition, bool& goingUp, int& sprEnemyPosition, float enemyPosition, int enemyId, int& sprWall1Position, int& sprWall2Position, int score, TTF_Font* scoreFont, SDL_Color white, int spellId, bool canCast)
{
  //Nettoyage de l'écran
  SDL_RenderClear(renderer);
  //Choix de ce qui va être afficher et où
  DisplayWall(renderer, sprWall1Position, sprWall2Position);
  DisplayScore(renderer, score, scoreFont, white);
  DisplayBook(renderer, canCast);
  DisplayHero(renderer, sprHeroPosition, goingUp);
  DisplaySpell(renderer, sprEnemyPosition, spellId);
  DisplayEnemy(renderer, sprEnemyPosition, enemyPosition, enemyId);
  DisplayBook(renderer, canCast);
  //Affichage de l'écran
  SDL_RenderPresent(renderer);
  //Légère pause si le joueur lance un sort
  if(spellId != -1 && spellId != 0)
  {
    SDL_Delay(500);
  }
}

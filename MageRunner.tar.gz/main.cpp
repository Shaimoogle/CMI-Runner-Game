#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include "input.hpp"
#include "environnement.hpp"
#include "graphics.hpp"

using namespace std;

int main(int argc, char *argv[])
{
  //Initialisation de la SDL et création de la fenêtre
  SDL_Init(SDL_INIT_VIDEO);
  IMG_Init(IMG_INIT_PNG);
  TTF_Init();
  SDL_Window* window;
  SDL_Renderer* renderer;
  CreateWindow(window, renderer);

  //Initialisation de l'aléatoire
  srand(time(NULL));

  //menu variables
  bool quitMenu;
  quitMenu = false;

  DisplayMenu(renderer);
  while (quitMenu == false) {
    MenuInput(quitMenu);
  }

  bool replay;
  replay = true;

  //Initializing input
  int input;

  while(replay && input != 0)
  {
    input = -1;

    //Initializing game environment
    float enemyPosition;
    enemyPosition = 100.0F;
    bool gameover;
    gameover = false;
    int enemyId;
    enemyId = 0;
    int spellId;
    spellId = -1;
    bool canCast;
    canCast = true;
    int enemyWeaknesses[3];
    enemyWeaknesses[0] = 1;
    enemyWeaknesses[1] = 2;
    enemyWeaknesses[2] = 3;
    bool enemyAlive;
    enemyAlive = true;
    float gameSpeed;
    gameSpeed = 9.0F;
    int score;
    score = 0;

    //Initializing graphics variables
    int heroSpritePositionY;
    heroSpritePositionY = 0;
    bool heroSpriteGoingUp;
    heroSpriteGoingUp = true;
    int enemySpritePositionX;
    enemySpritePositionX = 0;
    int wall1SpritePositionX;
    wall1SpritePositionX = 0;
    int wall2SpritePositionX;
    wall2SpritePositionX = 1280;
    //Variables graphiques pour le score
    TTF_Font* scoreFont;
    scoreFont = TTF_OpenFont("arial.ttf", 64);
    SDL_Color white;
    white.a = 0;
    white.r = 255;
    white.g = 255;
    white.b = 255;

    //gameloop
    while(!gameover && input != 0)
    {
      UpdateInput(input);
      UpdateEnvironment(input, enemyPosition, gameover, enemyId, spellId, canCast, enemyWeaknesses, enemyAlive, gameSpeed, score);
      UpdateGraphics(window, renderer, heroSpritePositionY, heroSpriteGoingUp, enemySpritePositionX, enemyPosition, enemyId, wall1SpritePositionX, wall2SpritePositionX, score, scoreFont, white, spellId, canCast);
    }

    input = -1;
    DisplayGameover(renderer);
    int gameoverInput;
    gameoverInput = -1;
    while(gameoverInput == -1)
    {
      ContinueInput(replay, gameoverInput);
    }

  }

  //Pause de 1 secondes
  SDL_Delay(1000);

  //Destruction de la fenêtre et fermeture du programme
  DestroyWindow(window, renderer);
  TTF_Quit();
  IMG_Quit();
  SDL_Quit();
  return 0;
}

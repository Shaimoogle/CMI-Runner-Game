#include "input.hpp"

using namespace std;

void UpdateInput(int& input)
{
    SDL_Event event;

    input = -1;

    SDL_Delay(17);
    SDL_PollEvent(&event);

    switch (event.type)
    {
      case SDL_QUIT:
        input = 0;
        break;

      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            input = 0;
            cout << "PRESSED ESCAPE" << endl;
            break;

          case SDLK_q:
            input = 1;
            cout << "PRESSED Q" << endl;
            break;

          case SDLK_s:
            input = 2;
            cout << "PRESSED S" << endl;
            break;

          case SDLK_d:
            input = 3;
            cout << "PRESSED D  " << endl;
            break;
        }
      }

}

void MenuInput(bool &quit)
{
  SDL_Event event;

  SDL_WaitEvent(&event);

  switch(event.type)
  {
    case SDL_KEYDOWN:
      switch(event.key.keysym.sym)
      {
        case SDLK_RETURN:
          quit = true;
          break;
      }
  }
}

void ContinueInput(bool &replay, int& gameoverInput)
{
  SDL_Event event;

  SDL_WaitEvent(&event);

    switch(event.type)
    {
      case SDL_QUIT:
        replay = false;
        gameoverInput = 0;
        break;

      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            replay = false;
            gameoverInput = 0;
            break;

          case SDLK_RETURN:
            gameoverInput = 0;
            break;
        }
    }
}

#include <stdlib.h>
#include <stdio.h>
#include <iostream>

using namespace std;

void moveEnemy(float& enemyPosition, int gameSpeed);

void checkDefeat(bool& gameover, float enemyPosition);

void checkEnemyDeath(int* weaknessesArray, int enemyId, int& spellId, bool& enemyAlive);

void generateEnemy(float& enemyPosition, int& enemyId, bool& enemyAlive, bool& canCast, int& score);

void castSpell(int input, int& spellId, bool& canCast);

void UpdateEnvironment(int input, float& enemyPosition, bool& gameover, int& enemyId, int& spellId, bool& canCast, int* enemyWeaknesses, bool& enemyAlive, float& gameSpeed, int& score);

void PrintEnvironment(int input, float enemyPosition, bool gameover, int enemyId, int spellId, bool canCast, bool enemyAlive, float gameSpeed);

#include <SDL2/SDL.h>
#include <iostream>

void PlaySpellSound(SDL_AudioDeviceID& deviceId, SDL_AudioSpec* wavSpec, Uint32 wavLength, Uint8* wavBuffer);
void UpdateAudio(SDL_AudioDeviceID& deviceId, SDL_AudioSpec& wavSpec, Uint32 wavLength, Uint8* wavBuffer, bool& castNow);
